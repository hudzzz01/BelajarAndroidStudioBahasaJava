package com.hudzzz.floatingmenu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menukanan, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        RelativeLayout re = (RelativeLayout) findViewById(R.id.re);

        switch (item.getItemId()){

            case 1 :
                re.setBackgroundColor(getResources().getColor(R.color.merah));
                break;
            case 2 :
                re.setBackgroundColor(getResources().getColor(R.color.biru));
                break;
            case 3 :
                re.setBackgroundColor(getResources().getColor(R.color.hijau));
                break;

        }


        return true;
    }
}